package com.perago.techtest;

import java.io.Serializable;

/**
 * The object representing a diff.
 * Implement this class as you see fit. 
 *
 */
public class Diff<T extends Serializable> {

}
