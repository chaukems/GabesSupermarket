/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.gabe.dao;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import za.co.gabe.entity.Product;

/**
 *
 * @author f4829689
 */
@Repository("productDao")
public class ProductsDaoImpl extends AbstractDao<Integer, Product> implements ProductsDao {

    public String add(Product product) {
        persist(product);
        return "Product added successfully";
    }

    public String updateProduct(Product product) {
        update(product);
        return "Product updated successfully";
    }

    public String deleteProduct(Product product) {
        delete(product);
        return "Product deleted successfully";
    }

    public Product get(int productId) {
        return getByKey(productId);
    }

    public void purchase(List<Product> products) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Product> findAll() {
        Criteria crit = createEntityCriteria();
        return crit.list();
    }

    public List<Product> reorderPointProducts() {
        Criteria crit = createEntityCriteria();
        crit.add(Restrictions.ge("measurementUnits", 10));
        return crit.list();
    }

}
