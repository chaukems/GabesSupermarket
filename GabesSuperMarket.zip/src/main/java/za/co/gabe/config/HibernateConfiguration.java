package za.co.gabe.config;

import java.util.Properties;
import javax.sql.DataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@ComponentScan({"za.co.gabe.config"})
public class HibernateConfiguration {

    final String driver = "com.mysql.jdbc.Driver";
    private String dbUsername = "gabe";
    private String dbPasswordEcrypted = "gabe";
    private String databaseName = "GabeSuperMarket";
    //private String dbPassword = ;

    /*HibernateConfiguration() {

     try {
     dbUsername = InitialContext.doLookup("java:global/dbusername");
     dbPasswordEcrypted = InitialContext.doLookup("java:global/dbpass");//;
     databaseName = InitialContext.doLookup("java:global/dbname");
     dbPassword = new DecryptController().decode(dbPasswordEcrypted);

     } catch (Exception ex) {
     Logger.getLogger(HibernateConfiguration.class.getName()).log(Level.SEVERE, null, ex);
     }
     }*/
    @Bean
    public LocalSessionFactoryBean sessionFactory() throws Exception {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setPackagesToScan(new String[]{"za.co.gabe.entity"});
        sessionFactory.setHibernateProperties(hibernateProperties());
        return sessionFactory;
    }

    @Bean
    public DataSource dataSource() throws Exception {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driver);
        dataSource.setUrl("jdbc:mysql://localhost:3306/" + databaseName);
        dataSource.setUsername(dbUsername);
        dataSource.setPassword(dbPasswordEcrypted);
        return dataSource;
    }

    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        properties.put("hibernate.show_sql", "false");
        properties.put("hibernate.format_sql", "true");
        return properties;
    }

    @Bean
    @Autowired
    public HibernateTransactionManager transactionManager(SessionFactory s) {
        HibernateTransactionManager txManager = new HibernateTransactionManager();
        txManager.setSessionFactory(s);
        return txManager;
    }

}
