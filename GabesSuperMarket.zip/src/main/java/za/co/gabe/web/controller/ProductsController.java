package za.co.gabe.web.controller;

import io.swagger.annotations.Api;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import za.co.gabe.entity.Product;
import za.co.gabe.service.ProductsService;

@RestController
@Api(description = "Prioducts management API")
public class ProductsController {

    private static final Logger logger = LoggerFactory.getLogger(ProductsController.class);

    @Autowired
    private ProductsService productsService;

    @RequestMapping(value = "/products", method = RequestMethod.GET)
    public @ResponseBody
    List<Product> findAll() {

        return productsService.findAll();
    }

    @RequestMapping(value = "/products/add", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String add(@RequestBody Product product) throws IOException {
        //byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer();
        byte[] btDataFile = Base64.getEncoder().encode(product.getImageBase64String().getBytes());

        product.setImage(btDataFile);

        return productsService.add(product);
    }

    @RequestMapping(value = "/products/update", method = RequestMethod.GET)
    public @ResponseBody
    String updateProduct(@RequestBody Product product) {

        return productsService.update(product);
    }

    @RequestMapping(value = "/products/delete", method = RequestMethod.GET)
    public @ResponseBody
    String deleteProduct(@RequestBody Product product) {

        return productsService.delete(product);
    }

    @RequestMapping(value = "/products/purchase", method = RequestMethod.POST)
    public @ResponseBody
    String purchase(@RequestBody List<Product> products) {

        //return gson.toJson(patientService.findPatientVisitByIdNo(searchBean.getIdNumber()));
        return "purchased";
    }

    @RequestMapping(value = {"/UploadFiles"}, method = RequestMethod.POST)
    public String UploadFiles(@RequestParam(value = "imageFilename", required = true) String imageFileName) {

        System.out.println("Uploading file ......" + imageFileName);

        return "uploaded";
    }

}
