package za.co.gabe.web.controller;

import com.google.gson.Gson;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import za.co.gabe.entity.Product;
import za.co.gabe.service.ProductsService;

@Controller
public class AppController {

    @Autowired
    Gson gson;

    @Autowired
    private ProductsService productsService;

    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public ModelAndView welcomePage() {

        StringBuilder productsList = new StringBuilder();

        for (Product product : productsService.findAll()) {
            // byte[] imageBytes = product.getImage().getBytes();
            System.out.println("product.getImage() = " + product.getImage());
            byte[] imageBytes = product.getImage();

            System.out.println("imageBytes = " + imageBytes);

            String imageData = Base64.getEncoder().encodeToString(imageBytes);

            System.out.println("imageData = " + imageData);

            productsList.append("<tr><td>").append(product.getBarcode())
                    .append("</td>" + "<td>").append(product.getName())
                    .append("</td>" + "<td>").append(product.getDescription())
                    .append("</td>" + "<td>").append(product.getMeasurementUnits())
                    .append("</td>" + "<td>").append(product.getMeasurementValue()).append("</td>" + "<td><img src='")
                    .append(imageData).append("'/></td>" + "<td><button type=\"button\" id = \"")
                    .append(product.getProductId())
                    .append("\" class=\"btn btnViewTasks btn-info btn-sm\" data-toggle=\"modal\" data-target=\"#updateModal\">Manage</button></td>"
                            + "</tr>");
        }

        ModelAndView model = new ModelAndView();
        model.addObject("productsList", productsList.toString());
        model.setViewName("welcome");
        return model;
    }

    @RequestMapping(value = "/reorder", method = RequestMethod.GET)
    public ModelAndView reorderPage() {

        StringBuilder productsList = new StringBuilder();

        for (Product product : productsService.reorderPointProducts()) {
            // byte[] imageBytes = product.getImage().getBytes();
            System.out.println("product.getImage() = " + product.getImage());
            byte[] imageBytes = product.getImage();

            System.out.println("imageBytes = " + imageBytes);

            String imageData = Base64.getEncoder().encodeToString(imageBytes);

            System.out.println("imageData = " + imageData);

            productsList.append("<tr><td>").append(product.getBarcode())
                    .append("</td>" + "<td>").append(product.getName())
                    .append("</td>" + "<td>").append(product.getDescription())
                    .append("</td>" + "<td>").append(product.getMeasurementUnits())
                    .append("</td>" + "<td>").append(product.getMeasurementValue()).append("</td>" + "<td><img src='")
                    .append(imageData).append("'/></td>" + "<td><button type=\"button\" id = \"")
                    .append(product.getProductId())
                    .append("\" class=\"btn btnViewTasks btn-info btn-sm\" data-toggle=\"modal\" data-target=\"#orderModal\">Order Product</button></td>"
                            + "</tr>");
        }

        ModelAndView model = new ModelAndView();
        model.addObject("productsList", productsList.toString());
        model.setViewName("reorderpoint");
        return model;
    }

    @RequestMapping(value = {"/", "/login"}, method = RequestMethod.GET)
    public ModelAndView login(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout) {

        ModelAndView model = new ModelAndView();
        if (error != null) {
            model.addObject("error", "Invalid username and password!");
        }

        if (logout != null) {
            model.addObject("msg", "You've been logged out successfully.");
        }
        model.setViewName("login");

        return model;
    }

}
