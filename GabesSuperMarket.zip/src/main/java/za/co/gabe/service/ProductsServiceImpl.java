/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.gabe.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.gabe.dao.ProductsDao;
import za.co.gabe.entity.Product;

/**
 *
 * @author f4829689
 */
@Service("productsService")
@Transactional
public class ProductsServiceImpl implements ProductsService {

    @Autowired
    private ProductsDao dao;

    public String add(Product product) {
        return dao.add(product);
    }

    public String update(Product product) {
        return dao.updateProduct(product);
    }

    public String delete(Product product) {
        return dao.deleteProduct(product);
    }

    public Product get(int productId) {
        return dao.get(productId);
    }

    public void purchase(List<Product> products) {
        dao.purchase(products);
    }

    public List<Product> findAll() {
        return dao.findAll();
    }

    public List<Product> reorderPointProducts() {
        return dao.reorderPointProducts();
    }

}
