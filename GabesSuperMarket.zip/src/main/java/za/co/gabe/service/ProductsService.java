/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.gabe.service;

import java.util.List;
import za.co.gabe.entity.Product;

/**
 *
 * @author f4829689
 */
public interface ProductsService {

    String add(Product product);

    String update(Product product);

    String delete(Product product);

    Product get(int productId);

    void purchase(List<Product> products);

    List<Product> findAll();
    
    List<Product> reorderPointProducts();

}
